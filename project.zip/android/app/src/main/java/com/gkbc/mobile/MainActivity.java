package com.gkbc.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
